The generated payload requires "requests" python library in order to be run.

### requests installation on Linux:
`pip install requests`

### requests installation on Windows:
If pip is not installed:
1. Download the library from https://pypi.python.org/pypi/request
2. Start the executable

Else:
`pip install requests`

### Generating the payload
To generate the payload read this page of the wiki: https://github.com/0blio/caesarRAT/wiki/Generating-the-payload
