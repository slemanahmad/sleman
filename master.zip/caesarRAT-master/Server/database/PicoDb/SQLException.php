<?php

namespace PicoDb;

use Exception;

/**
 * SQLException
 *
 * @package PicoDb
 * @author  Frederic Guillot
 */
class SQLException extends Exception
{
}
